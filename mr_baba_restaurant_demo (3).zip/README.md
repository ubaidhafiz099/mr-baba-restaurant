# Mr. Baba Ice & Food — Demo Website

A static, responsive demo for Vercel.

## Deploy on Vercel
1. Extract this ZIP.
2. Go to https://vercel.com/new and import the folder from a GitHub repository, or use the Vercel CLI from this folder.
3. No build command is required for this static HTML demo.
4. Deploy.

## Important
- Menu items and prices are demonstration examples. Verify the restaurant's actual menu/prices before showing it as operational.
- The cart, checkout form, and owner dashboard work in the browser for demo orders.
- Orders are not sent to the restaurant or saved to a shared database.
- Online payment, WhatsApp automation, live phone AI, SMS notifications, inventory, and multi-device owner access are not connected yet.
- Call and WhatsApp buttons use the supplied number +92 300 0618784.
